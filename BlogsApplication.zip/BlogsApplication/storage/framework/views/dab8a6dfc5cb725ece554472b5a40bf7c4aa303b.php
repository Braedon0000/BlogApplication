
<div class="card">
    <div class="px-3 pt-4 pb-2">
        <form enctype="multipart/form-data" method="POST" action="<?php echo e(route('users.update',$user->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
        <div class="d-flex align-items-center justify-content-between">
            <div class="d-flex align-items-center">

                <img style="width:150px" class="me-3 avatar-sm rounded-circle"
                    src="<?php echo e($user->getImageURL()); ?>" alt="Mario Avatar">
                <div>
                      <input name="name" value ="<?php echo e($user->name); ?>" type="text" class="-form-control">
                      <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span> <?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div>
                <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::id() === $user->id): ?>
                <a href="<?php echo e(route('users.show',$user->id)); ?>">view</a>
                <?php endif; ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="mt-4">
            <label for="">Profile Picture </label>
           <input name="image" class="form-control" type="file">
           <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <span> <?php echo e($message); ?></span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="px-2 mt-4">
            <h5 class="fs-5"> About : </h5>
            <div class="mb-3">
                <textarea name="bio" class="form-control" id="bio" rows="3"></textarea>
                <?php $__errorArgs = ['bio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="fs-6 text-danger"> <?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button class=""btn btn-dark btn-sm mt-3> save </button>
            <div class="d-flex justify-content-start">
                <a href="#" class="fw-light nav-link fs-6 me-3"> <span class="fas fa-user me-1">
                    </span> 120 Followers </a>
                <a href="#" class="fw-light nav-link fs-6 me-3"> <span class="fas fa-brain me-1">
                    </span><?php echo e($user->idea()->count()); ?> </a>
                <a href="#" class="fw-light nav-link fs-6"> <span class="fas fa-comment me-1">
                    </span> <?php echo e($user->comments()->count()); ?> </a>
            </div>
            <?php if(auth()->guard()->check()): ?>
             <?php if(Auth::id() !== $user->id): ?>

            <div class="mt-3">
                <button class="btn btn-primary btn-sm"> Follow </button>
            </div>
            <?php endif; ?>
            <?php endif; ?>
        </div>
    </form>
    </div>
</div>

<?php /**PATH C:\Users\braed\OneDrive\Desktop\UNI WORK\WEBFRAMEWORKS\BlogsApplication\resources\views/shared/user-edit-card.blade.php ENDPATH**/ ?>